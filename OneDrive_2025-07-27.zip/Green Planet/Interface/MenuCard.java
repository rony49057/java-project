package Interface;

public record MenuCard() {
}
