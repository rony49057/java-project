package Source;

public record Payment() {
}
